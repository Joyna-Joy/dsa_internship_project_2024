from flask import Flask, render_template, request
import numpy as np
import pickle
import csv
import datetime
app = Flask(__name__)


with open("label_encoder.pkl", "rb") as f:
    label_le = pickle.load(f)
with open("content_type_encoder.pkl", "rb") as f:
    content_type_le = pickle.load(f)
with open("model.pkl", "rb") as f:
    best_rf = pickle.load(f)

CSV_FILE = 'influencer_data.csv'

def load_influencer_data():
    with open(CSV_FILE, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        influencers = []
        for row in reader:
            influencers.append({
                "name": row["Influencer Name"],
                "country": row["Creator Country"],
                "subscribers": int(row["Subscriber Count"]),
                "content_type": row["Content Type"],
                "twitter_popularity": row["Popular on Twitter"],
                "instagram_popularity": row["Popular on Instagram"],
                "video_url": row["Most Viewed Video URL"],
                "channel_id": row["Channel ID"]
            })
        return influencers

def get_prediction_summary(pred_label):
    summaries = {
        "Viral": "This channel goes viral with high engagement and fast growth.",
        "Trending": "This channel is trending with steady growth and good engagement.",
        "Emerging": "This channel is new but growing and gaining attention.",
        "Niche": "This channel targets a specific audience with focused content."
    }
    return summaries.get(pred_label, "Prediction analysis complete.")

fields = [
    {"name": "subscriberCount", "label": "Subscriber Count", "placeholder": "e.g.100000"},
    {"name": "totalVideos", "label": "Total Videos", "placeholder": "e.g.150"},
    {"name": "avgViewsPerVideo", "label": "Avg Views per Video", "placeholder": "e.g.50000"},
    {"name": "avgLikesPerVideo", "label": "Avg Likes per Video", "placeholder": "e.g.2000"},
    {"name": "avgCommentsPerVideo", "label": "Avg Comments per Video", "placeholder": "e.g.150"},
    {"name": "viralityScore", "label": "Virality Score", "placeholder": "e.g.0.85"},
    {"name": "growthRate", "label": "Growth Rate Over Time", "placeholder": "e.g.15.2"},
    {"name": "engagementRate", "label": "Engagement Rate", "placeholder": "e.g.3.8"},
    {"name": "postFrequency", "label": "Post Frequency", "placeholder": "e.g.25"},
    {"name": "channelCreatedYear", "label": "Channel Created Year", "placeholder": "e.g.2018"},
    {"name": "toxicityScore", "label": "Toxicity Score", "placeholder": "e.g.0.23"},
    {"name": "contentType", "label": "Content Type"}
]
# Reverse the label encoder
content_types = content_type_le.inverse_transform(np.arange(len(content_type_le.classes_))).tolist()
years = list(range(datetime.datetime.now().year, 2004, -1))

@app.template_filter('format_subs')
def format_subs(subs):
    subs = int(subs)
    if subs >= 1_000_000:
        return f"{subs // 1_000_000}M"
    elif subs >= 1_000:
        return f"{subs // 1_000}K"
    return str(subs)

@app.template_filter('popularity_badge')
def popularity_badge(status):
    if "Highly" in status:
        return '<span class="badge badge-high">Highly Popular</span>'
    elif "Less" in status:
        return '<span class="badge badge-low">Less Popular</span>'
    else:
        return '<span class="badge badge-none">No Account</span>'


@app.route('/')
def index():
    return render_template("index.html", fields=fields, content_types=content_types, years=years)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        numeric_features = [
            float(request.form.get("subscriberCount")),
            float(request.form.get("totalVideos")),
            float(request.form.get("avgViewsPerVideo")),
            float(request.form.get("avgLikesPerVideo")),
            float(request.form.get("avgCommentsPerVideo")),
            float(request.form.get("viralityScore")),
            float(request.form.get("growthRate")),
            float(request.form.get("engagementRate")),
            float(request.form.get("postFrequency")),
            float(request.form.get("channelCreatedYear")),
            float(request.form.get("toxicityScore")),
        ]

        content_type = request.form.get("contentType")
        content_type_encoded = content_type_le.transform([content_type])[0] 

        all_features = numeric_features + [content_type_encoded]

        pred = best_rf.predict([all_features])[0]
        proba = best_rf.predict_proba([all_features])[0]
        confidence = round(np.max(proba) * 100, 2)
        pred_label = label_le.inverse_transform([pred])[0]

        color_class = {
            "Viral": "viral",
            "Trending": "trending",
            "Emerging": "emerging",
            "Niche": "niche",
        }.get(pred_label, "default")

        summary = get_prediction_summary(pred_label)
        return render_template("index.html",
                       prediction=pred_label,
                       confidence=confidence,
                       summary=summary,
                       color_class=color_class,
                       fields=fields,
                       content_types=content_types,
                       years=years,
                       prediction_class=color_class
                    )
    except Exception as e:
        return f"Error: {e}", 500
    
@app.route("/explore", methods=["GET"])
def explore():
    influencers = load_influencer_data()
    selected_country = request.args.get("country", "")
    selected_content_type = request.args.get("content_type", "")
    sort_by = request.args.get("sort_by", "subscribers")
    page = int(request.args.get("page", 1))
    per_page = 10
    
    # Remove duplicates by channel ID
    seen_channels = set()
    filtered = []
    for inf in influencers:
        if inf["channel_id"] in seen_channels:
            continue
        if (selected_country in ["", inf["country"]]) and (selected_content_type in ["", inf["content_type"]]):
            filtered.append(inf)
            seen_channels.add(inf["channel_id"])


    # Sorting
    popularity_rank = {
        "No Account": 2,
        "Less popular": 1,
        "Highly popular": 0
    }

    if sort_by in ["twitter_popularity", "instagram_popularity"]:
        sorted_influencers = sorted(
            filtered,
            key=lambda x: popularity_rank.get(x.get(sort_by, "No Account"), 0),
            reverse=False
        )
    else:
        sorted_influencers = sorted(
            filtered,
            key=lambda x: x.get(sort_by, 0) if sort_by == "subscribers" else str(x.get(sort_by, "")).lower(),
            reverse=True  
        )

    # Pagination
    total = len(sorted_influencers)
    start = (page - 1) * per_page
    end = start + per_page
    paginated = sorted_influencers[start:end]

    total_pages = (total + per_page - 1) // per_page  
    return render_template("explore.html",
        influencers=paginated,
        countries=sorted(set(inf["country"] for inf in influencers)),
        content_types=sorted(set(inf["content_type"] for inf in influencers)),
        selected_country=selected_country,
        selected_content_type=selected_content_type,
        current_page=page,
        total_pages=total_pages
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002, debug=True)