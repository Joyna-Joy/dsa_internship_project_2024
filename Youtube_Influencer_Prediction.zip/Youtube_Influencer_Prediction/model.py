import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pickle
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import warnings
warnings.filterwarnings('ignore')

# Read csv file
df=pd.read_csv("influencer_data.csv")
df.head()



# Display Rows and Columns

print('Number of rows:',df.shape[0])
print('Number of columns:',df.shape[1])
df.shape


# **Duplicate Rows**
df.duplicated().sum()
df.drop_duplicates(inplace=True)

# Dropping rows with missing values
df.dropna(subset=['Popularity Category Label','Popular on Twitter'], inplace=True)
df.isna().sum()

# **after dropping data with missing values**

print('Number of rows:',df.shape[0])
print('Number of columns:',df.shape[1])
df.shape

# Feature Engineering
# **Engagement Rate**
df['Engagement Rate'] = (
    (df['Avg Likes per Video'] + df['Avg Comments per Video']) /
    df['Subscriber Count'].replace(0, np.nan)
)

# **Account Age**
df['Account Age'] = 2025 - df['Channel Created Year']

# **Post Frequency**
df['Post Frequency'] = df['Total Videos'] / df['Account Age'].replace(0, np.nan)

df.columns

# df.to_csv("influencer_data.csv", index=False)
# print("Data saved to influencer_data.csv")

# **Label Encode the Target**

from sklearn.preprocessing import LabelEncoder
label_le = LabelEncoder()
df['Popularity Category Label'] = label_le.fit_transform(df['Popularity Category Label'])
# Map of what got encoded
label_map = dict(zip(label_le.classes_, label_le.transform(label_le.classes_)))
print("Target encoding:", label_map)

# **Content Type Encoding**
content_type_le = LabelEncoder()
df['Content Type'] = content_type_le.fit_transform(df['Content Type'])
# Map of what got encoded
label_map_c = dict(zip(content_type_le.classes_, content_type_le.transform(content_type_le.classes_)))
print("Target encoding:", label_map_c)

# # **Feature Selection**
selected_features = [
    'Subscriber Count','Total Videos', 'Avg Views per Video', 'Avg Likes per Video',
    'Avg Comments per Video','Virality Score',
    'Growth Rate Over Time', 'Engagement Rate', 
    'Post Frequency','Channel Created Year','Content Type', 'Toxicity Score']
target = 'Popularity Category Label'


df.dropna(inplace=True)

print('Number of rows:',df.shape[0])
print('Number of columns:',df.shape[1])
df.shape
# **Features Selection**

X = df[selected_features]
y = df['Popularity Category Label']


# **Train-Test Split**

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)


# **Model Training and Evaluation**
from sklearn.ensemble import RandomForestClassifier

rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred_rf))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred_rf))
print("\nClassification Report:\n", classification_report(y_test, y_pred_rf))


# **Hyper Tunning Random Forest**

from sklearn.model_selection import GridSearchCV
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [10, 20, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2'],
    'bootstrap': [True, False]
}

grid_search = GridSearchCV(estimator=RandomForestClassifier(random_state=42),
                           param_grid=param_grid,
                           cv=3,
                           n_jobs=-1,
                           verbose=2)

grid_search.fit(X_train, y_train)
best_rf = grid_search.best_estimator_

y_pred = best_rf.predict(X_test)
print("\nFinal Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))



# importing  pickle file 
# Save the label encoder
with open('label_encoder.pkl', 'wb') as f:
    pickle.dump(label_le, f)

# Save the content type encoder
with open('content_type_encoder.pkl', 'wb') as f:
    pickle.dump(content_type_le, f)

# Save the trained model
with open('model.pkl', 'wb') as f:
    pickle.dump(best_rf, f)

print("Scaler, Label Encoder, and Model have been saved as .pkl files.")